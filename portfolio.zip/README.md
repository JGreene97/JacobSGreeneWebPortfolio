# Jacob S Greene Web Portfolio
Jacob S Greene Personal Web Portfolio

Domain: jacobsgreene.com
Web Hosting Platform: TBD

This website Is currently in progress and is going to function as the Primary portfolio for Jacob.
This site may eventually contain subdomains which will navigate to addition personal Web projects Jacob has worked on.

This site is currently being built and will be coming soon

Icons provided by the following Authors from www.flaticon.com
Pixel Perfect
Freepik